package com.uptc.frw.vueltacolombia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VueltaColombiaApplicationTests {

    @Test
    void contextLoads() {
    }

}
