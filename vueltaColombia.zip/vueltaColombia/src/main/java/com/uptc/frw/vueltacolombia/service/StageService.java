package com.uptc.frw.vueltacolombia.service;

import com.uptc.frw.vueltacolombia.jpa.entity.Edition;
import com.uptc.frw.vueltacolombia.jpa.entity.Stage;
import com.uptc.frw.vueltacolombia.jpa.repository.EditionRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.StageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;

@Service
public class StageService {
    @Autowired
    private StageRepository stageRepository;
    @Autowired
    private EditionRepository editionRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public Stage saveStage(
            Long stageId,
            Long editionId,
            String type,
            String origin,
            String destination,
            Double length
            ){

        Stage stage = new Stage();

        Edition edition = editionRepository.findById(editionId).orElseThrow(() -> new EntityNotFoundException("No se encontró la edición con el ID proporcionado."));

        stage.setEditionId(edition);
        stage.setStageId(stageId);
        stage.setType(type);
        stage.setOrigin(origin);
        stage.setDestination(destination);
        stage.setLength(length);

        return stageRepository.save(stage);
    }
}
