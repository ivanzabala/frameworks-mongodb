package com.uptc.frw.vueltacolombia.service;

import com.uptc.frw.vueltacolombia.jpa.entity.*;
import com.uptc.frw.vueltacolombia.jpa.entity.key.TeamRunnerKey;
import com.uptc.frw.vueltacolombia.jpa.repository.EditionRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.RunnerRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.TeamRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.TeamRunnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TeamRunnerService {
    @Autowired
    private TeamRunnerRepository teamRunnerRepository;
    @Autowired
    private RunnerRepository runnerRepository;
    @Autowired
    private EditionRepository editionRepository;
    @Autowired
    private TeamRepository teamRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public void createTeamRunner(Long runnerId, Long editionId, Long teamId) {
        TeamRunner teamRunner = new TeamRunner();

        Runner runner = runnerRepository.findById(runnerId).orElseThrow(() -> new EntityNotFoundException("No se encontró el corredor con el ID proporcionado."));
        Edition edition = editionRepository.findById(editionId).orElseThrow(() -> new EntityNotFoundException("No se encontró la edición con el ID proporcionado."));
        Team team = teamRepository.findById(teamId).orElseThrow(() -> new EntityNotFoundException("No se encontró el equipo con el ID proporcionado."));

        teamRunner.setRunnerId(runner);
        teamRunner.setEditionId(edition);
        teamRunner.setTeamId(team);
        teamRunner.setTeamRunnerKey(new TeamRunnerKey(runnerId,editionId,teamId));

        teamRunnerRepository.save(teamRunner);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("create");
        auditEntry.setTable("teamRunner");
        Map<String, Object> data = new HashMap<>();
        data.put("runnerId", teamRunner.getRunnerId().getRunnerId());
        data.put("editionId", teamRunner.getEditionId().getEditionId());
        data.put("teamId", teamRunner.getTeamId().getTeamId());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry, "audit_entry");
    }

    public TeamRunner findTeamRunner(Long runnerId, Long editionId, Long teamId) {
        TeamRunnerKey teamRunnerKey = new TeamRunnerKey(runnerId, editionId, teamId);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("read");
        auditEntry.setTable("teamRunner");
        Map<String, Object> data = new HashMap<>();
        data.put("runnerId", teamRunnerKey.getRunnerId());
        data.put("editionId", teamRunnerKey.getEditionId());
        data.put("teamId", teamRunnerKey.getTeamId());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry, "audit_entry");

        return teamRunnerRepository.findById(teamRunnerKey)
                .orElseThrow(() -> new EntityNotFoundException("No se encontró el registro de TeamRunner con la clave primaria proporcionada."));
    }

    public List<TeamRunner> getAllTeamRunners() {
        List<TeamRunner> findAllTeamsRunner = teamRunnerRepository.findAll();

        for (TeamRunner teamRunner : findAllTeamsRunner) {
            AuditEntry auditEntry = new AuditEntry();
            auditEntry.setAction("read");
            auditEntry.setTable("teamRunner");
            Map<String, Object> data = new HashMap<>();
            data.put("runnerId", teamRunner.getRunnerId().getRunnerId());
            data.put("editionId", teamRunner.getEditionId().getEditionId());
            data.put("teamId", teamRunner.getTeamId().getTeamId());



            auditEntry.setData(data);
            mongoTemplate.save(auditEntry, "audit_entry");
        }
        return teamRunnerRepository.findAll();
    }

    public TeamRunner updateTeamRunnerKey(Long runnerId, Long editionId, Long teamId, Long newRunnerId) {

        TeamRunnerKey originalKey = new TeamRunnerKey(runnerId, editionId, teamId);
        TeamRunner existingTeamRunner = teamRunnerRepository.findById(originalKey)
                .orElseThrow(() -> new EntityNotFoundException("No se encontró el registro de TeamRunner con la clave primaria proporcionada."));

        existingTeamRunner.getTeamRunnerKey().setRunnerId(newRunnerId);
        teamRunnerRepository.save(existingTeamRunner);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("read");
        auditEntry.setTable("teamRunner");
        Map<String, Object> data = new HashMap<>();
        data.put("runnerId", existingTeamRunner.getRunnerId().getRunnerId());
        data.put("editionId", existingTeamRunner.getEditionId().getEditionId());
        data.put("teamId", existingTeamRunner.getTeamId().getTeamId());


        auditEntry.setData(data);
        mongoTemplate.save(auditEntry, "audit_entry");
        return teamRunnerRepository.save(existingTeamRunner);
    }
}
