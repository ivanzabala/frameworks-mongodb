package com.uptc.frw.vueltacolombia.service;

import com.uptc.frw.vueltacolombia.jpa.entity.AuditEntry;
import com.uptc.frw.vueltacolombia.jpa.entity.Team;
import com.uptc.frw.vueltacolombia.jpa.repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TeamService {
    @Autowired
    private TeamRepository teamRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public Team saveTeam(Team team){
        Team savedTeam = teamRepository.save(team);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("create");
        auditEntry.setTable("team");
        Map<String, Object> data = new HashMap<>();
        data.put("participated",savedTeam.getParticipated());
        data.put("teamId",savedTeam.getTeamId());
        data.put("teamName",savedTeam.getTeamName());
        data.put("date",savedTeam.getDateFun());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
        return teamRepository.save(savedTeam);
    }

    public Team findTeam(Long id){
        Team findedTeam = teamRepository.findById(id).get();

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("read");
        auditEntry.setTable("team");
        Map<String, Object> data = new HashMap<>();
        data.put("teamId",findedTeam.getTeamId());
        data.put("teamName",findedTeam.getTeamName());
        data.put("date",findedTeam.getDateFun());
        data.put("participated",findedTeam.getParticipated());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
        return teamRepository.findById(id).get();
    }

    public List<Team> findAllTeam(){
        List<Team> findAllTeams = teamRepository.findAll();

        for (Team team : findAllTeams) {
            AuditEntry auditEntry = new AuditEntry();
            auditEntry.setAction("read");
            auditEntry.setTable("team");
            Map<String, Object> data = new HashMap<>();
            data.put("teamId",team.getTeamId());
            data.put("teamName",team.getTeamName());
            data.put("date",team.getDateFun());
            data.put("participated",team.getParticipated());

            auditEntry.setData(data);
            mongoTemplate.save(auditEntry, "audit_entry");
        }
        return teamRepository.findAll();
    }

    public Team updateTeamName(Long id, String teamName){
        Team findedTeam = findTeam(id);
        findedTeam.setTeamName(teamName);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("update");
        auditEntry.setTable("team");
        Map<String, Object> data = new HashMap<>();
        data.put("teamId",findedTeam.getTeamId());
        data.put("teamName",findedTeam.getTeamName());
        data.put("date",findedTeam.getDateFun());
        data.put("participated",findedTeam.getParticipated());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");

        return teamRepository.save(findedTeam);
    }

    public void deleteTeam(Long id){
        Team findedTeam = teamRepository.findById(id).get();
        teamRepository.delete(findedTeam);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("delete");
        auditEntry.setTable("team");
        Map<String, Object> data = new HashMap<>();
        data.put("teamId",findedTeam.getTeamId());
        data.put("teamName",findedTeam.getTeamName());
        data.put("date",findedTeam.getDateFun());
        data.put("participated",findedTeam.getParticipated());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
    }
}
