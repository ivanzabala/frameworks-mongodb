package com.uptc.frw.vueltacolombia.jpa.repository;

import com.uptc.frw.vueltacolombia.jpa.entity.Runner;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RunnerRepository extends JpaRepository<Runner, Long> {
}
