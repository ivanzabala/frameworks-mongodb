package com.uptc.frw.vueltacolombia.jpa.entity.key;

import com.uptc.frw.vueltacolombia.jpa.entity.Edition;
import com.uptc.frw.vueltacolombia.jpa.entity.Runner;
import com.uptc.frw.vueltacolombia.jpa.entity.Team;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;


@Embeddable
public class TeamRunnerKey implements Serializable {
    @Column(name = "id_corredor")
    private Long runnerId;
    @Column(name = "id_edicion")
    private Long editionId;
    @Column(name = "id_equipo")
    private Long teamId;

    public TeamRunnerKey() {
    }

    public TeamRunnerKey(Long runnerId, Long editionId, Long teamId) {
        this.runnerId = runnerId;
        this.editionId = editionId;
        this.teamId = teamId;
    }

    public Long getRunnerId() {
        return runnerId;
    }

    public void setRunnerId(Long runnerId) {
        this.runnerId = runnerId;
    }

    public Long getEditionId() {
        return editionId;
    }

    public void setEditionId(Long editionId) {
        this.editionId = editionId;
    }

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }
}
