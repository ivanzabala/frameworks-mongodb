package com.uptc.frw.vueltacolombia.controller;

import com.uptc.frw.vueltacolombia.jpa.entity.Team;
import com.uptc.frw.vueltacolombia.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/team")
public class TeamController {
    @Autowired
    private TeamService teamService;

    @PostMapping("/createTeam")
    public Team saveTeam(
            @RequestBody Team team
    ){
        return teamService.saveTeam(team);
    }

    @GetMapping("/findTeam/{id}")
    public Team findTeamById(@PathVariable Long id){
        return teamService.findTeam(id);
    }

    @GetMapping("/allTeams")
    public List<Team> findAllTeams(){
        return teamService.findAllTeam();
    }

    @PutMapping("/updateTeam/{id}")
    public Team updateTeamName(
            @PathVariable Long id,
            @RequestParam String name
    ){
        return teamService.updateTeamName(id,name);
    }

    @DeleteMapping("/deleteTeam/{id}")
    public void deleteTeam(
            @PathVariable Long id
    ){
        teamService.deleteTeam(id);
    }
}
