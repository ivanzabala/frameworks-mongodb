package com.uptc.frw.vueltacolombia.service;

import com.uptc.frw.vueltacolombia.jpa.entity.AuditEntry;
import com.uptc.frw.vueltacolombia.jpa.entity.Runner;
import com.uptc.frw.vueltacolombia.jpa.repository.RunnerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RunnerService {
    @Autowired
    private RunnerRepository runnerRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public Runner saveRunner(Runner runner){
        Runner savedRunner = runnerRepository.save(runner);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("create");
        auditEntry.setTable("runner");
        Map<String, Object> data = new HashMap<>();
        data.put("runnerId",savedRunner.getRunnerId());
        data.put("runnerName",savedRunner.getRunnerName());
        data.put("countryBirth",savedRunner.getCountryBirth());
        data.put("dateBirth",savedRunner.getDateBirth());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
        return runnerRepository.save(savedRunner);
    }

    public Runner findRunner(Long id){
        Runner findedRunner = runnerRepository.findById(id).get();

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("read");
        auditEntry.setTable("runner");
        Map<String, Object> data = new HashMap<>();
        data.put("runnerId",findedRunner.getRunnerId());
        data.put("runnerName",findedRunner.getRunnerName());
        data.put("countryBirth",findedRunner.getCountryBirth());
        data.put("dateBirth",findedRunner.getDateBirth());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
        return runnerRepository.findById(id).get();
    }

    public List<Runner> findAllRunners(){
        List<Runner> findAllRunner = runnerRepository.findAll();

        for (Runner runner : findAllRunner) {
            AuditEntry auditEntry = new AuditEntry();
            auditEntry.setAction("read");
            auditEntry.setTable("runner");
            Map<String, Object> data = new HashMap<>();
            data.put("runnerId",runner.getRunnerId());
            data.put("runnerName",runner.getRunnerName());
            data.put("countryBirth",runner.getCountryBirth());
            data.put("dateBirth",runner.getDateBirth());

            auditEntry.setData(data);
            mongoTemplate.save(auditEntry, "audit_entry");
        }
        return runnerRepository.findAll();
    }

    public Runner updateRunnerName(Long id, String runnerName){
        Runner findedRunner = findRunner(id);
        findedRunner.setRunnerName(runnerName);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("update");
        auditEntry.setTable("runner");
        Map<String, Object> data = new HashMap<>();
        data.put("runnerId",findedRunner.getRunnerId());
        data.put("runnerName",findedRunner.getRunnerName());
        data.put("countryBirth",findedRunner.getCountryBirth());
        data.put("dateBirth",findedRunner.getDateBirth());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");

        return runnerRepository.save(findedRunner);
    }

    public void deleteRunner(Long id){
        Runner findedRunner = runnerRepository.findById(id).get();
        runnerRepository.delete(findedRunner);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("delete");
        auditEntry.setTable("runner");
        Map<String, Object> data = new HashMap<>();
        data.put("runnerId",findedRunner.getRunnerId());
        data.put("runnerName",findedRunner.getRunnerName());
        data.put("countryBirth",findedRunner.getCountryBirth());
        data.put("dateBirth",findedRunner.getDateBirth());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
    }

}
