package com.uptc.frw.vueltacolombia.jpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.uptc.frw.vueltacolombia.jpa.entity.key.TeamRunnerKey;
import com.uptc.frw.vueltacolombia.jpa.entity.key.TeamSponsorKey;

import javax.persistence.*;

@Entity
@Table(name = "EQUIPOS_CORREDORES")
public class TeamRunner {

    @EmbeddedId
    private TeamRunnerKey teamRunnerKey;
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_corredor",insertable = false, updatable = false)
    private Runner runnerId;


    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_edicion", insertable = false, updatable = false)
    private Edition editionId;


    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_equipo",insertable = false,updatable = false)
    private Team teamId;

    public TeamRunner() {
    }

    public TeamRunner(TeamRunnerKey teamRunnerKey) {
        this.teamRunnerKey = teamRunnerKey;
    }

    public Runner getRunnerId() {
        return runnerId;
    }

    public void setRunnerId(Runner runnerId) {
        this.runnerId = runnerId;
    }

    public Edition getEditionId() {
        return editionId;
    }

    public void setEditionId(Edition editionId) {
        this.editionId = editionId;
    }

    public Team getTeamId() {
        return teamId;
    }

    public void setTeamId(Team teamId) {
        this.teamId = teamId;
    }

    public TeamRunnerKey getTeamRunnerKey() {
        return teamRunnerKey;
    }

    public void setTeamRunnerKey(TeamRunnerKey teamRunnerKey) {
        this.teamRunnerKey = teamRunnerKey;
    }
}
