package com.uptc.frw.vueltacolombia.jpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.uptc.frw.vueltacolombia.jpa.entity.key.PodiumKey;

import javax.persistence.*;
import java.sql.Time;
import java.util.List;
import java.util.Timer;

@Entity
@Table(name = "PODIOS")
public class Podium {

    @EmbeddedId
    private PodiumKey podiumKey;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "id_etapa",insertable = false, updatable = false)
    private Stage stageId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_corredor", insertable = false, updatable = false)
    private Runner runnerId;

    @Column(name = "tiempo")
    private Time runnerTime;

    @Column(name = "posicion")
    private int position;

    public Podium() {
    }

    public Podium(Stage stageId, Runner runnerId, Time runnerTime, int position) {
        this.stageId = stageId;
        this.runnerId = runnerId;
        this.runnerTime = runnerTime;
        this.position = position;
    }

    public Podium(PodiumKey podiumKey) {
        this.podiumKey = podiumKey;
    }

    public Stage getStageId() {
        return stageId;
    }

    public void setStageId(Stage stageId) {
        this.stageId = stageId;
    }

    public Runner getRunnerId() {
        return runnerId;
    }

    public void setRunnerId(Runner runnerId) {
        this.runnerId = runnerId;
    }

    public Time getRunnerTime() {
        return runnerTime;
    }

    public void setRunnerTime(Time runnerTime) {
        this.runnerTime = runnerTime;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public PodiumKey getPodiumKey() {
        return podiumKey;
    }

    public void setPodiumKey(PodiumKey podiumKey) {
        this.podiumKey = podiumKey;
    }
}

