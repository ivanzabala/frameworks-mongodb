package com.uptc.frw.vueltacolombia.jpa.repository;

import com.uptc.frw.vueltacolombia.jpa.entity.AuditEntry;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AuditEntryRepository extends MongoRepository<AuditEntry,String> {
}
