package com.uptc.frw.vueltacolombia.controller;

import com.uptc.frw.vueltacolombia.jpa.entity.Sponsor;
import com.uptc.frw.vueltacolombia.service.SponsorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sponsor")
public class SponsorController {
    @Autowired
    private SponsorService sponsorService;

    @PostMapping("/createSponsor")
    public Sponsor saveSponsor(
            @RequestBody Sponsor sponsor
    ){
        return sponsorService.saveSponsor(sponsor);
    }

    @GetMapping("/findSponsor/{id}")
    public Sponsor findSponsorById(@PathVariable Long id){
        return sponsorService.findSponsor(id);
    }

    @GetMapping("/allSponsors")
    public List<Sponsor> findAllSponsors(){
        return sponsorService.findAllSponsor();
    }

    @PutMapping("/updateSponsor/{id}")
    public Sponsor updateSponsorName(
            @PathVariable Long id,
            @RequestParam String name
    ){
        return sponsorService.updateSponsorName(id,name);
    }

    @DeleteMapping("/deleteSponsor/{id}")
    public void deleteSponsor(
            @PathVariable Long id
    ){
      sponsorService.deleteSponsor(id);
    }
}
