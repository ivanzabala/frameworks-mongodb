package com.uptc.frw.vueltacolombia.jpa.entity.key;

import com.uptc.frw.vueltacolombia.jpa.entity.Runner;
import com.uptc.frw.vueltacolombia.jpa.entity.Stage;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class PodiumKey implements Serializable {

    @Column(name = "id_etapa")
    private Long stageId;
    @Column(name = "id_corredor")
    private Long runnerId;

    public PodiumKey() {
    }

    public PodiumKey(Long stageId, Long runnerId) {
        this.stageId = stageId;
        this.runnerId = runnerId;
    }

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public Long getRunnerId() {
        return runnerId;
    }

    public void setRunnerId(Long runnerId) {
        this.runnerId = runnerId;
    }
}