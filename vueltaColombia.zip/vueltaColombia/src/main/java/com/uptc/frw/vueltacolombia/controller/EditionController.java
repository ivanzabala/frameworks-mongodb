package com.uptc.frw.vueltacolombia.controller;

import com.uptc.frw.vueltacolombia.jpa.entity.Edition;
import com.uptc.frw.vueltacolombia.service.EditionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/edition")
public class EditionController {
    @Autowired
    private EditionService editionService;

    @PostMapping("/createEdition")
    public Edition saveEdition(
            @RequestBody Edition edition)
    {
        return editionService.saveEdition(edition);
    }

    @GetMapping("/findEdition/{id}")
    public Edition findTeamById(@PathVariable Long id){
        return editionService.findEdition(id);
    }

    @GetMapping("/allEditions")
    public List<Edition> findAllTeams(){
        return editionService.findAllEditions();
    }

    @PutMapping("/updateEdition/{id}")
    public Edition updateTeamName(
            @PathVariable Long id,
            @RequestParam Integer anio
    ){
        return editionService.updateYearEdition(id, anio);
    }

    @DeleteMapping("/deleteEdition/{id}")
    public void deleteTeam(
            @PathVariable Long id
    ){
        editionService.deleteEdition(id);
    }
}
