package com.uptc.frw.vueltacolombia.jpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "PATROCINADORES")
public class Sponsor {
    @Id
    @Column(name = "nit_patrocinador")
    private Long sponsorId;

    @Column(name = "nombre")
    private String sponsorName;

    @JsonIgnore
    @OneToMany(mappedBy = "sponsorNit", cascade = CascadeType.PERSIST)
    private List<TeamSponsor> teamSponsors;

    public Sponsor() {
    }

    public Long getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(Long sponsorId) {
        this.sponsorId = sponsorId;
    }

    public String getSponsorName() {
        return sponsorName;
    }

    public void setSponsorName(String sponsorName) {
        this.sponsorName = sponsorName;
    }

    public List<TeamSponsor> getTeamSponsors() {
        return teamSponsors;
    }

    public void setTeamSponsors(List<TeamSponsor> teamSponsors) {
        this.teamSponsors = teamSponsors;
    }

}
