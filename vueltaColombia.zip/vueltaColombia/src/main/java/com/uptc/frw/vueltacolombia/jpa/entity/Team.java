package com.uptc.frw.vueltacolombia.jpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "EQUIPOS")
public class Team {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_equipo")
    private Long teamId;

    @Column(name ="nombre")
    private String teamName;

    @Column(name = "fecha_fundacion")
    private Date dateFun;

    @Column(name = "participacion")
    private String participated;

    @JsonIgnore
    @OneToMany(mappedBy = "teamId",cascade = CascadeType.PERSIST)
    private List<TeamSponsor> teamSponsors;

    @JsonIgnore
    @OneToMany(mappedBy = "teamId", cascade = CascadeType.PERSIST)
    private List<TeamRunner> teamRunners;

    public Team() {
    }

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public Date getDateFun() {
        return dateFun;
    }

    public void setDateFun(Date dateFun) {
        this.dateFun = dateFun;
    }

    public String getParticipated() {
        return participated;
    }

    public void setParticipated(String participated) {
        this.participated = participated;
    }

    public List<TeamSponsor> getTeamSponsors() {
        return teamSponsors;
    }

    public void setTeamSponsors(List<TeamSponsor> teamSponsors) {
        this.teamSponsors = teamSponsors;
    }

    public List<TeamRunner> getTeamRunners() {
        return teamRunners;
    }

    public void setTeamRunners(List<TeamRunner> teamRunners) {
        this.teamRunners = teamRunners;
    }
}
