package com.uptc.frw.vueltacolombia.service;

import com.uptc.frw.vueltacolombia.jpa.entity.*;
import com.uptc.frw.vueltacolombia.jpa.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class EditionService {
    @Autowired
    private EditionRepository editionRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public Edition saveEdition(Edition edition){
        Edition savedEdition = editionRepository.save(edition);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("create");
        auditEntry.setTable("edition");
        Map<String, Object> data = new HashMap<>();
        data.put("anio", savedEdition.getAnio());
        data.put("editionId", savedEdition.getEditionId());
        data.put("fechaIni", savedEdition.getFechaIni());
        data.put("fechaFin", savedEdition.getFechaFin());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry, "audit_entry");
        return editionRepository.save(savedEdition);
    }
        public Edition findEdition(Long id){
            Edition findedEdition = editionRepository.findById(id).get();

            AuditEntry auditEntry = new AuditEntry();
            auditEntry.setAction("read");
            auditEntry.setTable("team");
            Map<String, Object> data = new HashMap<>();
            data.put("editionId",findedEdition.getEditionId());
            data.put("anio",findedEdition.getAnio());
            data.put("fechaIni",findedEdition.getFechaIni());
            data.put("fechaFin",findedEdition.getFechaFin());

            auditEntry.setData(data);
            mongoTemplate.save(auditEntry,"audit_entry");
            return editionRepository.findById(id).get();
        }

    public List<Edition> findAllEditions(){
        List<Edition> findAllEditions = editionRepository.findAll();

        for (Edition edition : findAllEditions) {
            AuditEntry auditEntry = new AuditEntry();
            auditEntry.setAction("read");
            auditEntry.setTable("edition");
            Map<String, Object> data = new HashMap<>();
            data.put("editionId",edition.getEditionId());
            data.put("anio",edition.getAnio());
            data.put("fechaIni",edition.getFechaIni());
            data.put("fechaFin",edition.getFechaFin());

            auditEntry.setData(data);
            mongoTemplate.save(auditEntry, "audit_entry");
        }
        return editionRepository.findAll();
    }

    public Edition updateYearEdition(Long id, int anio){
        Edition findedEdition = findEdition(id);
        findedEdition.setAnio(anio);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("update");
        auditEntry.setTable("edition");
        Map<String, Object> data = new HashMap<>();
        data.put("editionId",findedEdition.getEditionId());
        data.put("anio",findedEdition.getAnio());
        data.put("fechaIni",findedEdition.getFechaIni());
        data.put("fechaFin",findedEdition.getFechaFin());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");

        return editionRepository.save(findedEdition);
    }

    public void deleteEdition(Long id){
        Edition findedEdition = editionRepository.findById(id).get();
        editionRepository.delete(findedEdition);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("delete");
        auditEntry.setTable("edition");
        Map<String, Object> data = new HashMap<>();
        data.put("editionId",findedEdition.getEditionId());
        data.put("anio",findedEdition.getAnio());
        data.put("fechaIni",findedEdition.getFechaIni());
        data.put("fechaFin",findedEdition.getFechaFin());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
    }
}
