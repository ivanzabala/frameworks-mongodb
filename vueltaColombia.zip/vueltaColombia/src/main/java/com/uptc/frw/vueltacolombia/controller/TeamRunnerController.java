package com.uptc.frw.vueltacolombia.controller;

import com.uptc.frw.vueltacolombia.jpa.entity.TeamRunner;
import com.uptc.frw.vueltacolombia.jpa.entity.key.TeamRunnerKey;
import com.uptc.frw.vueltacolombia.service.TeamRunnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@RestController
@RequestMapping("/teamRunner")
public class TeamRunnerController {
    @Autowired
    private TeamRunnerService teamRunnerService;

    @PostMapping("/create")
    public ResponseEntity<String> createTeamRunner(
            @RequestParam Long runnerId,
            @RequestParam Long editionId,
            @RequestParam Long teamId) {

        try {
            teamRunnerService.createTeamRunner(runnerId, editionId, teamId);
            return ResponseEntity.ok("TeamRunner creado con éxito.");
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error: " + ex.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno del servidor: " + e.getMessage());
        }
    }

    @GetMapping("/findById/{runnerId}/{editionId}/{teamId}")
    public ResponseEntity<TeamRunner> findTeamRunner(
            @PathVariable Long runnerId,
            @PathVariable Long editionId,
            @PathVariable Long teamId
    ) {
        TeamRunner teamRunner = teamRunnerService.findTeamRunner(runnerId, editionId, teamId);
        return ResponseEntity.ok(teamRunner);
    }

    @GetMapping("/all")
    public ResponseEntity<List<TeamRunner>> getAllTeamRunners() {
        List<TeamRunner> teamRunners = teamRunnerService.getAllTeamRunners();
        return ResponseEntity.ok(teamRunners);
    }

    @PutMapping("/{runnerId}/{editionId}/{teamId}/{newRunnerId}")
    public ResponseEntity<TeamRunner> updateTeamRunnerKeyComponent(
            @PathVariable Long runnerId,
            @PathVariable Long editionId,
            @PathVariable Long teamId,
            @PathVariable Long newRunnerId
    ) {
        TeamRunner updatedTeamRunner = teamRunnerService.updateTeamRunnerKey(runnerId, editionId, teamId, newRunnerId);
        return ResponseEntity.ok(updatedTeamRunner);
    }
}
