package com.uptc.frw.vueltacolombia.controller;

import com.uptc.frw.vueltacolombia.jpa.entity.Stage;
import com.uptc.frw.vueltacolombia.service.StageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/stage")
public class StageController {
    @Autowired
    private StageService stageService;

    @PostMapping("/createStage")
    public Stage saveStage(
            @RequestParam Long stageId,
            @RequestParam Long editionId,
            @RequestParam String type,
            @RequestParam String origin,
            @RequestParam String destination,
            @RequestParam Double length
    ){
        return stageService.saveStage(stageId,
                editionId,
                type,
                origin,
                destination,
                length);
    }
}
