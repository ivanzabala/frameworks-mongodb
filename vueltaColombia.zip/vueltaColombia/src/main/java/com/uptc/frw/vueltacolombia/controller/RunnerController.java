package com.uptc.frw.vueltacolombia.controller;

import com.uptc.frw.vueltacolombia.jpa.entity.Runner;
import com.uptc.frw.vueltacolombia.service.RunnerService;
import com.uptc.frw.vueltacolombia.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/runner")
public class RunnerController {
    @Autowired
    private RunnerService runnerService;

    @PostMapping("/createRunner")
    public Runner saveRunner(
            @RequestBody Runner runner
    ){
        return runnerService.saveRunner(runner);

    }

    @GetMapping("/findRunner/{id}")
    public Runner findTeamById(@PathVariable Long id){ return runnerService.findRunner(id); }

    @GetMapping("/allRunners")
    public List<Runner> findAllRunners(){return runnerService.findAllRunners();}

    @PutMapping("/updateRunner/{id}")
    public Runner updateRunnerName(
            @PathVariable Long id,
            @RequestParam String name
    ) {
        return runnerService.updateRunnerName(id, name);
    }

    @DeleteMapping("/daleteRunner/{id}")
    public void deleteRunner(
            @PathVariable Long id
    ){
        runnerService.deleteRunner(id);
    }

}
