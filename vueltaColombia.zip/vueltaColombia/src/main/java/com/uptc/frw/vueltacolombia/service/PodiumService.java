package com.uptc.frw.vueltacolombia.service;

import com.uptc.frw.vueltacolombia.jpa.entity.AuditEntry;
import com.uptc.frw.vueltacolombia.jpa.entity.Podium;
import com.uptc.frw.vueltacolombia.jpa.entity.Runner;
import com.uptc.frw.vueltacolombia.jpa.entity.Stage;
import com.uptc.frw.vueltacolombia.jpa.entity.key.PodiumKey;
import com.uptc.frw.vueltacolombia.jpa.repository.PodiumRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.RunnerRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.StageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.sql.Time;
import java.util.HashMap;;
import java.util.Map;

@Service
public class PodiumService {
    @Autowired
    private PodiumRepository podiumRepository;
    @Autowired
    private RunnerRepository runnerRepository;
    @Autowired
    private StageRepository stageRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public Podium savepodium(Long stageId, Long runnerId, Time runerTime, int position) {

        Podium podium = new Podium();

        Runner runner = runnerRepository.findById(runnerId).orElseThrow(() -> new EntityNotFoundException("No se encontró el corredor con el ID proporcionado."));
        Stage stage = stageRepository.findById(stageId).orElseThrow(() -> new EntityNotFoundException("No se encontró la etapa con el ID proporcionado."));

        podium.setRunnerId(runner);
        podium.setStageId(stage);
        podium.setRunnerTime(runerTime);
        podium.setPosition(position);
        podium.setPodiumKey(new PodiumKey(runnerId,stageId));

        podiumRepository.save(podium);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("create");
        auditEntry.setTable("podium");
        Map<String, Object> data = new HashMap<>();
        data.put("stageId", podium.getStageId().getStageId());
        data.put("runnerId", podium.getRunnerId().getRunnerId());
        data.put("runnerTime", podium.getRunnerTime());
        data.put("position", podium.getPosition());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry, "audit_entry");
        return podiumRepository.save(podium);
    }

    public Podium findpodium(Stage stage, Runner runner) {
        return podiumRepository.findByStageIdAndRunnerId(stage, runner);
    }
}
