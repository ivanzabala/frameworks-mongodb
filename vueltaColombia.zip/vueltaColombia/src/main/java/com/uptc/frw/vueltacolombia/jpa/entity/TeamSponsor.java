package com.uptc.frw.vueltacolombia.jpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.uptc.frw.vueltacolombia.jpa.entity.key.TeamSponsorKey;

import javax.persistence.*;

@Entity
@Table(name = "EQUIPOS_PATROCINADORES")
public class TeamSponsor {

    @EmbeddedId
    private TeamSponsorKey teamSponsorKey;
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_edicion", nullable = false, insertable = false, updatable = false)
    private Edition editionId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "id_equipo", nullable = false, insertable = false, updatable = false)
    private Team teamId;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "nit_patrocinador", nullable = false, insertable = false, updatable = false)
    private Sponsor sponsorNit;

    public TeamSponsor() {
    }

    public TeamSponsor(TeamSponsorKey teamSponsorKey) {
        this.teamSponsorKey = teamSponsorKey;
    }

    public Edition getEditionId() {
        return editionId;
    }

    public void setEditionId(Edition editionId) {
        this.editionId = editionId;
    }

    public Team getTeamId() {
        return teamId;
    }

    public void setTeamId(Team teamId) {
        this.teamId = teamId;
    }

    public Sponsor getSponsorNit() {
        return sponsorNit;
    }

    public void setSponsorNit(Sponsor sponsorNit) {
        this.sponsorNit = sponsorNit;
    }

    public TeamSponsorKey getTeamSponsorKey() {
        return teamSponsorKey;
    }

    public void setTeamSponsorKey(TeamSponsorKey teamSponsorKey) {
        this.teamSponsorKey = teamSponsorKey;
    }
}
