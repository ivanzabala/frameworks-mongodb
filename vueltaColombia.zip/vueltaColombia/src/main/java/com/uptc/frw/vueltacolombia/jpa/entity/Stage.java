package com.uptc.frw.vueltacolombia.jpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "ETAPAS")
public class Stage {
    @Id
    @Column(name = "id_etapa")
    private Long stageId;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "id_edicion", nullable = false)
    private Edition editionId;

    @Column(name = "tipo")
    private String type;

    @Column(name = "origen")
    private String origin;

    @Column(name = "destino")
    private String destination;

    @Column(name = "longitud")
    private Double length;

    @JsonIgnore
    @OneToMany(mappedBy = "stageId", cascade = CascadeType.PERSIST)
    private List<Podium> podiums;

    public Stage() {
    }

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public Edition getEditionId() {
        return editionId;
    }

    public void setEditionId(Edition editionId) {
        this.editionId = editionId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public Double getLength() {
        return length;
    }

    public void setLength(Double length) {
        this.length = length;
    }

    public List<Podium> getPodiums() {
        return podiums;
    }

    public void setPodiums(List<Podium> podiums) {
        this.podiums = podiums;
    }

    @Override
    public String toString() {
        return "Stage{" +
                "editionId=" + editionId +
                '}';
    }
}
