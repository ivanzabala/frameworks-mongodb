package com.uptc.frw.vueltacolombia.jpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "EDICIONES ")
public class Edition {
    @Id
    @Column(name = "id_edicion")
    private Long editionId;

    @Column(name = "anio")
    private Integer anio;

    @Column(name = "fecha_inicial")
    private Date fechaIni;

    @Column(name = "fecha_final")
    private Date fechaFin;

    @JsonIgnore
    @OneToMany(mappedBy = "editionId", cascade = CascadeType.PERSIST)
    private List<Stage> stages;

    @JsonIgnore
    @OneToMany(mappedBy = "editionId", cascade = CascadeType.PERSIST)
    private List<TeamSponsor> teamSponsors;

    @JsonIgnore
    @OneToMany(mappedBy = "editionId", cascade = CascadeType.PERSIST)
    private List<TeamRunner> teamRunners;

    public Edition() {
    }

    public Long getEditionId() {
        return editionId;
    }

    public void setEditionId(Long editionId) {
        this.editionId = editionId;
    }

    public Integer getAnio() {
        return anio;
    }

    public void setAnio(Integer anio) {
        this.anio = anio;
    }

    public Date getFechaIni() {
        return fechaIni;
    }

    public void setFechaIni(Date fechaIni) {
        this.fechaIni = fechaIni;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public List<Stage> getStages() {
        return stages;
    }

    public void setStages(List<Stage> stages) {
        this.stages = stages;
    }

    public List<TeamSponsor> getTeamSponsors() {
        return teamSponsors;
    }

    public void setTeamSponsors(List<TeamSponsor> teamSponsors) {
        this.teamSponsors = teamSponsors;
    }

    public List<TeamRunner> getTeamRunners() {
        return teamRunners;
    }

    public void setTeamRunners(List<TeamRunner> teamRunners) {
        this.teamRunners = teamRunners;
    }

    @Override
    public String toString() {
        return "Edition{" +
                "editionId=" + editionId +
                ", anio=" + anio +
                ", fechaIni=" + fechaIni +
                ", fechaFin=" + fechaFin +
                ", stages=" + stages +
                ", teamSponsors=" + teamSponsors +
                ", teamRunners=" + teamRunners +
                '}';
    }
}
