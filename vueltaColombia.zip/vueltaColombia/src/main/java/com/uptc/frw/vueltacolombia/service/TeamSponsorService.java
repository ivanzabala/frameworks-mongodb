package com.uptc.frw.vueltacolombia.service;

import com.uptc.frw.vueltacolombia.jpa.entity.*;
import com.uptc.frw.vueltacolombia.jpa.entity.key.TeamRunnerKey;
import com.uptc.frw.vueltacolombia.jpa.entity.key.TeamSponsorKey;
import com.uptc.frw.vueltacolombia.jpa.repository.EditionRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.SponsorRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.TeamRepository;
import com.uptc.frw.vueltacolombia.jpa.repository.TeamSponsorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.HashMap;
import java.util.Map;

@Service
public class TeamSponsorService {
    @Autowired
    private TeamSponsorRepository teamSponsorRepository;
    @Autowired
    private TeamRepository teamRepository;
    @Autowired
    private SponsorRepository sponsorRepository;
    @Autowired
    private EditionRepository editionRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public void createTeamSponsor(Long editionId, Long teamId, Long sponsorId) {
        TeamSponsor teamSponsor = new TeamSponsor();

        Sponsor sponsor = sponsorRepository.findById(sponsorId).orElseThrow(() -> new EntityNotFoundException("No se encontró el patrocinador con el ID proporcionado."));
        Edition edition = editionRepository.findById(editionId).orElseThrow(() -> new EntityNotFoundException("No se encontró la edición con el ID proporcionado."));
        Team team = teamRepository.findById(teamId).orElseThrow(() -> new EntityNotFoundException("No se encontró el equipo con el ID proporcionado."));

        teamSponsor.setSponsorNit(sponsor);
        teamSponsor.setEditionId(edition);
        teamSponsor.setTeamId(team);
        teamSponsor.setTeamSponsorKey(new TeamSponsorKey(sponsorId,editionId,teamId));

        teamSponsorRepository.save(teamSponsor);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("create");
        auditEntry.setTable("teamSponsor");
        Map<String, Object> data = new HashMap<>();
        data.put("sponsorId", teamSponsor.getSponsorNit().getSponsorId());
        data.put("editionId", teamSponsor.getEditionId().getEditionId());
        data.put("teamId", teamSponsor.getTeamId().getTeamId());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry, "audit_entry");
    }
}
