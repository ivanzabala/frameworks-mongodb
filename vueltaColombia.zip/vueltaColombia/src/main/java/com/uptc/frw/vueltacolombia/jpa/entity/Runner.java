package com.uptc.frw.vueltacolombia.jpa.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "CORREDORES")
public class Runner {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_corredor")
    private Long runnerId;

    @Column(name = "nombre")
    private String runnerName;

    @Column(name = "pais_nacimiento")
    private String countryBirth;

    @Column(name = "fecha_nacimiento")
    private Date dateBirth;

    @JsonIgnore
    @OneToMany(mappedBy = "runnerId",cascade = CascadeType.PERSIST)
    private List<Podium> podiums;

    @JsonIgnore
    @OneToMany(mappedBy = "runnerId", cascade = CascadeType.PERSIST)
    private List<TeamRunner> teamRunners;

    public Runner() {
    }

    public Long getRunnerId() {
        return runnerId;
    }

    public void setRunnerId(Long runnerId) {
        this.runnerId = runnerId;
    }

    public String getRunnerName() {
        return runnerName;
    }

    public void setRunnerName(String runnerName) {
        this.runnerName = runnerName;
    }

    public String getCountryBirth() {
        return countryBirth;
    }

    public void setCountryBirth(String countryBirth) {
        this.countryBirth = countryBirth;
    }

    public Date getDateBirth() {
        return dateBirth;
    }

    public void setDateBirth(Date dateBirth) {
        this.dateBirth = dateBirth;
    }

    public List<Podium> getPodiums() {
        return podiums;
    }

    public void setPodiums(List<Podium> podiums) {
        this.podiums = podiums;
    }

    public List<TeamRunner> getTeamRunners() {
        return teamRunners;
    }

    public void setTeamRunners(List<TeamRunner> teamRunners) {
        this.teamRunners = teamRunners;
    }


}
