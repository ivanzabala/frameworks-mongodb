package com.uptc.frw.vueltacolombia.jpa.repository;

import com.uptc.frw.vueltacolombia.jpa.entity.Podium;
import com.uptc.frw.vueltacolombia.jpa.entity.Runner;
import com.uptc.frw.vueltacolombia.jpa.entity.Stage;
import com.uptc.frw.vueltacolombia.jpa.entity.key.PodiumKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PodiumRepository extends JpaRepository<Podium, PodiumKey> {
    Podium findByStageIdAndRunnerId(Stage stage, Runner runner);
}
