package com.uptc.frw.vueltacolombia.jpa.entity;

import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Id;
import java.util.Map;

@Document(collection = "audit_entry")
public class AuditEntry {
    @Id
    private String id;
    private String action;
    private String table;
    private Map<String,Object> data;

    public AuditEntry() {
    }

    public AuditEntry(String action, String table, Map<String, Object> data) {
        this.action = action;
        this.table = table;
        this.data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "AuditEntry{" +
                "id='" + id + '\'' +
                ", action='" + action + '\'' +
                ", table='" + table + '\'' +
                ", data=" + data +
                '}';
    }
}
