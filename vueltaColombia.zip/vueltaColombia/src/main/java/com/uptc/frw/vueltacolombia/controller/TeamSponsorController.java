package com.uptc.frw.vueltacolombia.controller;

import com.uptc.frw.vueltacolombia.service.TeamSponsorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.persistence.EntityNotFoundException;

@RestController
@RequestMapping("/teamSponsor")
public class TeamSponsorController {
    @Autowired
    private TeamSponsorService teamSponsorService;

    @PostMapping("/create")
    public ResponseEntity<String> createTeamRunner(
            @RequestParam Long sponsorId,
            @RequestParam Long editionId,
            @RequestParam Long teamId) {

        try {
            teamSponsorService.createTeamSponsor(sponsorId, editionId, teamId);
            return ResponseEntity.ok("TeamRunner creado con éxito.");
        } catch (EntityNotFoundException ex) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Error: " + ex.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno del servidor: " + e.getMessage());
        }
    }
}
