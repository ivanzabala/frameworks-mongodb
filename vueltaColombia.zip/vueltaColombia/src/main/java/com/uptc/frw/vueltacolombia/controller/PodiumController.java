package com.uptc.frw.vueltacolombia.controller;

import com.uptc.frw.vueltacolombia.jpa.entity.Podium;
import com.uptc.frw.vueltacolombia.service.PodiumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Time;

@RestController
@RequestMapping("/podium")
public class PodiumController {
    @Autowired
    private PodiumService podiumService;

    @PostMapping("/createPodium")
    public Podium savePodium(
            @RequestParam Long stageId,
            @RequestParam Long runnerId,
            @RequestParam Time runnerTime,
            @RequestParam Integer position
    ){
     return podiumService.savepodium(stageId,runnerId,runnerTime,position);
    }
}
