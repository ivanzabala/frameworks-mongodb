package com.uptc.frw.vueltacolombia.service;

import com.uptc.frw.vueltacolombia.jpa.entity.AuditEntry;
import com.uptc.frw.vueltacolombia.jpa.entity.Sponsor;
import com.uptc.frw.vueltacolombia.jpa.repository.SponsorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SponsorService {
    @Autowired
    private SponsorRepository sponsorRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public Sponsor saveSponsor(Sponsor sponsor){
        Sponsor savedSponsor = sponsorRepository.save(sponsor);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("create");
        auditEntry.setTable("sponsor");
        Map<String, Object> data = new HashMap<>();
        data.put("sponsorId",savedSponsor.getSponsorId());
        data.put("sponsorName",savedSponsor.getSponsorName());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
        return sponsorRepository.save(savedSponsor);
    }

    public Sponsor findSponsor(Long id){
        Sponsor findedSponsor = sponsorRepository.findById(id).get();

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("read");
        auditEntry.setTable("sponsor");
        Map<String, Object> data = new HashMap<>();
        data.put("sponsorId",findedSponsor.getSponsorId());
        data.put("sponsorName",findedSponsor.getSponsorName());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
        return sponsorRepository.findById(id).get();
    }

    public List<Sponsor> findAllSponsor(){
        List<Sponsor> findAllSponsors = sponsorRepository.findAll();

        for (Sponsor sponsor : findAllSponsors) {
            AuditEntry auditEntry = new AuditEntry();
            auditEntry.setAction("read");
            auditEntry.setTable("sponsor");
            Map<String, Object> data = new HashMap<>();
            data.put("sponsorId",sponsor.getSponsorId());
            data.put("sponsorName",sponsor.getSponsorName());

            auditEntry.setData(data);
            mongoTemplate.save(auditEntry, "audit_entry");
        }
        return sponsorRepository.findAll();
    }

    public Sponsor updateSponsorName(Long id, String sponsorName){
        Sponsor findedSponsor = findSponsor(id);
        findedSponsor.setSponsorName(sponsorName);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("update");
        auditEntry.setTable("sponsor");
        Map<String, Object> data = new HashMap<>();
        data.put("sponsorId",findedSponsor.getSponsorId());
        data.put("sponsorName",findedSponsor.getSponsorName());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");

        return sponsorRepository.save(findedSponsor);
    }

    public void deleteSponsor(Long id){
        Sponsor findedSponsor = sponsorRepository.findById(id).get();
        sponsorRepository.delete(findedSponsor);

        AuditEntry auditEntry = new AuditEntry();
        auditEntry.setAction("delete");
        auditEntry.setTable("sponsor");
        Map<String, Object> data = new HashMap<>();
        data.put("sponsorId",findedSponsor.getSponsorId());
        data.put("sponsorName",findedSponsor.getSponsorName());

        auditEntry.setData(data);
        mongoTemplate.save(auditEntry,"audit_entry");
    }
}
